Upload as an Overleaf project. Select poster.tex and pdfLaTeX. Poster size: 61 x 85 cm.
